import React, { useEffect, useState } from "react";

export default function DerList() {
    const [data, setData] = useState([]);
    const [expandedSections, setExpandedSections] = useState({}); // Track expanded state per category

    useEffect(() => {
        async function fetchData() {
            const res = await fetch("/data.json");
            const json = await res.json();
            setData(json.sort((a, b) => a.category.localeCompare(b.category)));
        }

        fetchData();
    }, []);

    const toggleSection = (category) => {
        setExpandedSections((prev) => ({
            ...prev,
            [category]: !prev[category],
        }));
    };

    return (
        <div style={{ padding: "20px", marginTop: "200px" }}>
            {data
                .sort((a, b) => a.category.localeCompare(b.category))
                .map((section, index) => (
                    <div
                        key={index}
                        style={{
                            marginTop: "40px", // avoids top cut-off
                        }}
                    >
                        <h2 style={{ marginBottom: "10px", color: "#2e86de" }}>
                            {section.category}
                        </h2>

                        {/* Scrollable item container */}
                        <div
                            style={{
                                maxHeight: "200px", // Adjust height as needed
                                overflowY: "auto",
                                paddingRight: "10px",
                                border: "1px solid #ccc",
                                borderRadius: "6px",
                                backgroundColor: "#f1f1f1",
                            }}
                        >
                            {section.items.map((item, i) => (
                                <div
                                    key={item.english + i}
                                    style={{
                                        margin: "10px",
                                        padding: "10px",
                                        border: "1px solid #ddd",
                                        borderRadius: "4px",
                                        backgroundColor: "#fff",
                                    }}
                                >
                                    <div style={{ fontWeight: "bold" }}>
                                        {item.english} / {item.german} / {item.arabic}
                                    </div>
                                    <div>{item.usage}</div>
                                    <div>{item.arabicUsage}</div>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
        </div>

    );
}
