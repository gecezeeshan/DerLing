import './App.css';
import DerTranslate from "./DerTranslate";
import DerGame from "./DerGame";
import DerList from './DerList';
import { useState } from 'react';

export default function VocabGame() {
  const [Dictionary, setDictionary] = useState(true);



  return (
    <>
      {!Dictionary &&
        <>
          <div>test</div>

          <div className="container">
            <div className="row">
              <div className="column">
                <>
                  <DerGame></DerGame>
                  <button onClick={() => setDictionary(true)} >Show Dictionary</button>
                </>
              </div>
              <div className="column">
                <DerTranslate></DerTranslate>
              </div>
            </div>
          </div>
        </>
      }
      {Dictionary &&

        <div>
          <h1>Dictionary</h1>
          <DerList></DerList>
          <button onClick={() => setDictionary(false)} >Show Game</button>
        </div>}



    </>
  );
}
